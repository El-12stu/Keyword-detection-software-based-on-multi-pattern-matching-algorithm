#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "/home/aymurat/ac-regex/ac_lib/ac-change.h"
#include "/home/aymurat/ac-regex/ac_lib/ac-match.h"
#include "/home/aymurat/ac-regex/regex_lib/regex-match.h"
#include "/home/aymurat/ac-regex/regex_lib/regex-change.h"

// 声明回调函数
void on_button2_clicked(GtkButton *button, gpointer user_data);
void on_button3_clicked(GtkButton *button, gpointer user_data);
void on_button5_clicked(GtkButton *button, gpointer user_data);
void on_button6_clicked(GtkButton *button, gpointer user_data);
void on_button8_clicked(GtkButton *button, gpointer user_data);
void on_button9_clicked(GtkButton *button, gpointer user_data);

int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv); // 初始化 GTK
    GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    GtkWidget* button1 = gtk_button_new_with_label("欢迎来到关键词匹配系统，请选择你需要匹配的模式");
    GtkWidget* button2 = gtk_button_new_with_label("AC算法");
    GtkWidget* button3 = gtk_button_new_with_label("regex算法");

    GtkWidget* table = gtk_table_new(4, 5, TRUE);

    gtk_widget_set_size_request(window, 200, 200);

    gtk_container_add(GTK_CONTAINER(window), table);

    gtk_table_attach_defaults(GTK_TABLE(table), button1, 1, 4, 0, 1);
    gtk_table_attach_defaults(GTK_TABLE(table), button2, 1, 2, 2, 3);
    gtk_table_attach_defaults(GTK_TABLE(table), button3, 3, 4, 2, 3);

    // 连接按钮点击信号
    g_signal_connect(button2, "clicked", G_CALLBACK(on_button2_clicked), NULL);
    g_signal_connect(button3, "clicked", G_CALLBACK(on_button3_clicked), NULL);

    gtk_widget_show_all(window);

    // 进入 GTK 事件循环
    gtk_main();

    return 0;
}
void on_button2_clicked(GtkButton *button, gpointer user_data)
{
        gtk_init(NULL,NULL);//任何gtk程序都以这个开始
	GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	GtkWidget* button4 = gtk_button_new_with_label("欢迎来到AC匹配系统，请选择你需要的模式");
	GtkWidget* button5 = gtk_button_new_with_label("AC匹配模式");
	GtkWidget* button6 = gtk_button_new_with_label("AC关键词增添模式");

        GtkWidget* table = gtk_table_new(4,5,TRUE);

	gtk_widget_set_size_request(window,200,200);

	gtk_container_add(GTK_CONTAINER(window),table);

        gtk_table_attach_defaults(GTK_TABLE(table),button4,1,4,0,1);
        gtk_table_attach_defaults(GTK_TABLE(table),button5,1,2,2,3);
        gtk_table_attach_defaults(GTK_TABLE(table),button6,3,4,2,3);

        g_signal_connect(button5, "clicked", G_CALLBACK(on_button5_clicked), NULL);
        g_signal_connect(button6, "clicked", G_CALLBACK(on_button6_clicked), NULL);



	gtk_widget_show_all(window);

	gtk_main();//gtk事件监听
	return 0;
}
void on_button3_clicked(GtkButton *button, gpointer user_data)
{
        gtk_init(NULL,NULL);//任何gtk程序都以这个开始
	GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	GtkWidget* button7 = gtk_button_new_with_label("欢迎来到regex匹配系统，请选择你需要的模式");
	GtkWidget* button8 = gtk_button_new_with_label("regex匹配模式");
	GtkWidget* button9 = gtk_button_new_with_label("regex关键词增添模式");

        GtkWidget* table = gtk_table_new(4,5,TRUE);

	gtk_widget_set_size_request(window,200,200);

	gtk_container_add(GTK_CONTAINER(window),table);

        gtk_table_attach_defaults(GTK_TABLE(table),button7,1,4,0,1);
        gtk_table_attach_defaults(GTK_TABLE(table),button8,1,2,2,3);
        gtk_table_attach_defaults(GTK_TABLE(table),button9,3,4,2,3);

        g_signal_connect(button8, "clicked", G_CALLBACK(on_button8_clicked), NULL);
        g_signal_connect(button9, "clicked", G_CALLBACK(on_button9_clicked), NULL);



	gtk_widget_show_all(window);

	gtk_main();//gtk事件监听
	return 0;
}
void on_button5_clicked(GtkButton *button, gpointer user_data)
{
        create_ui();
}
void on_button6_clicked(GtkButton *button, gpointer user_data)
{
        start_program();
}
void on_button8_clicked(GtkButton *button, gpointer user_data)
{
        work(NULL,NULL);
}
void on_button9_clicked(GtkButton *button, gpointer user_data)
{
        regexChange();
}


