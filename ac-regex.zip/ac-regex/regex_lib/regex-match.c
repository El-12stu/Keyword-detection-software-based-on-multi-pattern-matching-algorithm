#include "regex-match.h"

static int matchPattern(regex_t* pattern, const char* text, int* matchlength);
static int matchCharclass(char c, const char* str);
static int matchStar(regex_t p, regex_t* pattern, const char* text, int* matchlength);
static int matchPlus(regex_t p, regex_t* pattern, const char* text, int* matchlength);
static int matchOne(regex_t p, char c);
static int matchDigit(char c);      
static int matchAlpha(char c);
static int matchWhitespace(char c);
static int matchMetachar(char c, const char* str);
static int matchRange(char c, const char* str);
static int matchDot(char c);
static int isMetachar(char c);
//输入正则表达式形式的pattern，匹配正则表达式，是外层匹配函数
int reMatcho(const char* pattern, const char* text, int* matchlength)//输入需要匹配的正则表达式与文本
{
  return reMatchi(reCompile(pattern), text, matchlength); //将pattern编译成re_t类后进行匹配
}
//真正的匹配函数，是内层的匹配函数
int reMatchi(re_t pattern, const char* text, int* matchlength)//pattern 是接受编译之后的正则表达式模式，text是文本，matchlength表示匹配长度
{
  *matchlength = 0;
  if (pattern != 0)
  {
    //识别到pattern第一个匹配到的类型为“BEGIN”
    //直接调用matchPattern,对pattern[1]进行匹配
    if (pattern[0].type == BEGIN)
    {
      return ((matchPattern(&pattern[1], text, matchlength)) ? 0 : -1);
    }
    else
    {
      int idx = -1;
      do
      {
        idx += 1;
        if (matchPattern(pattern, text, matchlength))
        {
          if (text[0] == '\0')
            return -1;

          return idx;
        }
      }
      while (*text++ != '\0');
    }
  }
  return -1;
}
//编译pattern并返回re_t类型
re_t reCompile(const char* pattern)
{
  //  MAX_REGEXP_OBJECTS 和 MAX_CHAR_CLASS_LEN 已经在.h中定义，分别表示re_compile和ccl_buf中的最大空间
  static regex_t re_compiled[MAX_REGEXP_OBJECTS];
  static unsigned char ccl_buf[MAX_CHAR_CLASS_LEN];
  int ccl_bufidx = 1;

  char c;     /* 使用c来记录当前识别到的字符   */
  int i = 0;  /* 用于在pattern中计数        */
  int j = 0;  /* 用于在re_compile中计数  */

  while (pattern[i] != '\0' && (j+1 < MAX_REGEXP_OBJECTS))
  {
    c = pattern[i];

    switch (c)
    {
      case '^': {    re_compiled[j].type = BEGIN;           } break;
      case '$': {    re_compiled[j].type = END;             } break;
      case '.': {    re_compiled[j].type = DOT;             } break;
      case '*': {    re_compiled[j].type = STAR;            } break;
      case '+': {    re_compiled[j].type = PLUS;            } break;
      case '?': {    re_compiled[j].type = QUESTIONMARK;    } break;
      case '|': {    re_compiled[j].type = BRANCH;          } break;
      /* 针对未列入的涉及更复杂类型，继续用几个case来处理*/
      case '\\':
      {
        if (pattern[i+1] != '\0')
        {
          /* 通过+1跳过'\\' */
          i += 1;
          /*对下一个进行匹配检测*/
          switch (pattern[i])
          {
            /*通过pattern传入的正则表达式串，逐字为re_compiled[j]的type匹配对应的enum中的类型*/
            case 'd': {    re_compiled[j].type = DIGIT;            } break;
            case 'D': {    re_compiled[j].type = NOT_DIGIT;        } break;
            case 'w': {    re_compiled[j].type = ALPHA;            } break;
            case 'W': {    re_compiled[j].type = NOT_ALPHA;        } break;
            case 's': {    re_compiled[j].type = WHITESPACE;       } break;
            case 'S': {    re_compiled[j].type = NOT_WHITESPACE;   } break;
//			case '|': {    re_compiled[j].type = BRANCH;          } break;
            /* 除上述六种类型，其他的皆可以归类于char类型 */
            default:
            {
              re_compiled[j].type = CHAR;
              //**
              re_compiled[j].u.ch = pattern[i];
            } break;
          }
        }
        //判断“\\”作为串尾，直接break出
      } break;

      /* 匹配到对char类型的封装*/
      case '[':
      {
        /* 保存下char类型封装的起点 */

        int buf_begin = ccl_bufidx;

        /* 判断是否为其实符号'^' */
        if (pattern[i+1] == '^')
        {
          re_compiled[j].type = INV_CHAR_CLASS;
          i += 1; //i+1以避开符号^
          if (pattern[i+1] == 0) //避开空的char
          {
            return 0;
          }
        }
        else
        {
          re_compiled[j].type = CHAR_CLASS;
        }
        /*将pattern转移到ccl_bufidx中*/
        while (    (pattern[++i] != ']')
                && (pattern[i]   != '\0')) 
        {
          if (pattern[i] == '\\')
          {
            if (ccl_bufidx >= MAX_CHAR_CLASS_LEN - 1)
            {  
             return 0;
            }
            if (pattern[i+1] == 0) 
            {
              return 0;
            }
            ccl_buf[ccl_bufidx++] = pattern[i++];
          }
          else if (ccl_bufidx >= MAX_CHAR_CLASS_LEN)
          {
              //fputs("exceeded internal buffer!\n", stderr);
              return 0;
          }
          ccl_buf[ccl_bufidx++] = pattern[i];
        }
        if (ccl_bufidx >= MAX_CHAR_CLASS_LEN)
        {
            /* Catches cases such as [00000000000000000000000000000000000000][ */
            //fputs("exceeded internal buffer!\n", stderr);
            return 0;
        }
        /* 以零做串尾 */
        ccl_buf[ccl_bufidx++] = 0;
        re_compiled[j].u.ccl = &ccl_buf[buf_begin];
      } break;

      /* 其余归类于char */
      default:
      {
        re_compiled[j].type = CHAR;
        re_compiled[j].u.ch = c;
      } break;
    }
    /* 无效模式上没有缓冲区越界访问. */
    if (pattern[i] == 0)
    {
      return 0;
    }

    i += 1;
    j += 1;
  }
/*使用unused作为pattern串的结尾*/   
  re_compiled[j].type = UNUSED;

  return (re_t) re_compiled;
}
void rePrint(regex_t* pattern) 
{
  const char* types[] = {"UNUSED", "DOT", "BEGIN", "END", "QUESTIONMARK", "STAR", "PLUS", "CHAR","CHAR_CLASS", "INV_CHAR_CLASS", "DIGIT", "NOT_DIGIT", "ALPHA", "NOT_ALPHA","WHITESPACE", "NOT_WHITESPACE", "BRANCH"};

    int i = 0;

    while (i < MAX_REGEXP_OBJECTS) 
    {
        // 如果类型为UNUSED，表示没有更多的正则表达式对象，退出循环
        if (pattern[i].type == UNUSED) 
        {
            break;
        }

        // 打印正则表达式对象的类型
        printf("type: %s", types[pattern[i].type]);

        // 如果是字符类别或者反向字符类别，打印字符集合
        if (pattern[i].type == CHAR_CLASS || pattern[i].type == INV_CHAR_CLASS) 
        {
            printf(" [");
            // 遍历字符集合，直到遇到 '\0' 或者 ']'
            int j = 0;
            char c;
            while (j < MAX_CHAR_CLASS_LEN) 
            {
                c = pattern[i].u.ccl[j];
                if (c == '\0' || c == ']') 
                {
                    break;
                }
                printf("%c", c);
                j++;
            }
            printf("]");
        }
        // 如果是普通字符，打印字符
        else if (pattern[i].type == CHAR) 
        {
            printf(" '%c'", pattern[i].u.ch);
        }
        printf("\n");

        i++;  // 更新索引以继续下一个循环
    }
}

static int matchDigit(char c)
{
  return isdigit(c);
}
static int matchAlpha(char c)
{
  return isalpha(c);
}
static int matchWhitespace(char c)
{
  return isspace(c);
}
static int matchAlphanum(char c)
{
  return ((c == '_') || matchAlpha(c) || matchDigit(c));
}

static int matchRange(char c, const char* str)
{
  return (    (c != '-')
           && (str[0] != '\0')
           && (str[0] != '-')
           && (str[1] == '-')
           && (str[2] != '\0')
           && (    (c >= str[0])
                && (c <= str[2])));
}

static int matchDot(char c)
{
#if defined(RE_DOT_MATCHES_NEWLINE) && (RE_DOT_MATCHES_NEWLINE == 1)
  (void)c;
  return 1;
#else
  return c != '\n' && c != '\r';
#endif
}

static int isMetachar(char c)
{
  return ((c == 's') || (c == 'S') || (c == 'w') || (c == 'W') || (c == 'd') || (c == 'D'));
}

static int matchMetachar(char c, const char* str)
{
  switch (str[0])
  {
    case 'd': return  matchDigit(c);
    case 'D': return !matchDigit(c);
    case 'w': return  matchAlphanum(c);
    case 'W': return !matchAlphanum(c);
    case 's': return  matchWhitespace(c);
    case 'S': return !matchWhitespace(c);
    default:  return (c == str[0]);
  }
}

static int matchCharclass(char c, const char* str) 
{
    do 
    {
        // 检查字符范围
        if (matchRange(c, str)) 
        {
            return 1;
        } 
        else if (str[0] == '\\') 
        {
            /* 转义字符：增加字符串指针并匹配下一个字符 */
            str += 1;
            // 如果转义字符后的字符是元字符，返回 1
            if (matchMetachar(c, str)) 
            {
                return 1;
            }
            // 如果转义字符后的字符与 'c' 相等且不是元字符，返回 1
            else if ((c == str[0]) && !isMetachar(c)) 
            {
                return 1;
            }
        } 
        else if (c == str[0]) 
        {
            // 如果 'c' 与 'str' 中的字符相等，且不是 '-'，返回 1
            if (c == '-' && (str[-1] == '\0' || str[1] == '\0'))
            {
                return 1;
            } 
            else if (c != '-') 
            {
                return 1;
            }
        }
    } 
    while (*str++ != '\0');

    // 未找到匹配项，返回 0
    return 0;
}

static int matchOne(regex_t p, char c)
{

  switch (p.type)
  {
    case DOT:            return  matchDot(c);
    case CHAR_CLASS:     return  matchCharclass(c, (const char*)p.u.ccl);
    case INV_CHAR_CLASS: return !matchCharclass(c, (const char*)p.u.ccl);
    case DIGIT:          return  matchDigit(c);
    case NOT_DIGIT:      return !matchDigit(c);
    case ALPHA:          return  matchAlphanum(c);
    case NOT_ALPHA:      return !matchAlphanum(c);
    case WHITESPACE:     return  matchWhitespace(c);
    case NOT_WHITESPACE: return !matchWhitespace(c);
    default:             return  (p.u.ch == c);
  }
}

static int matchStar(regex_t p, regex_t* pattern, const char* text, int* matchlength)
{
  int prelen = *matchlength;
  const char* prepoint = text;
   // 循环匹配文本中与正则表达式模式中的单个字符匹配的部分
  while ((text[0] != '\0') && matchOne(p, *text))
  {
    text++;
    (*matchlength)++;
  }
  // 逆序遍历已经匹配的字符，尝试匹配剩余部分的正则表达式
  while (text >= prepoint)
  {
    // 如果成功匹配剩余的正则表达式模式，返回 1 表示匹配成功
    // 如果回溯后的文本不为空，且仍然与正则表达式模式匹配，继续尝试匹配
    if (matchPattern(pattern, text--, matchlength))
      return 1;
      // 回溯：减少匹配长度
    (*matchlength)--;
  }
  // 恢复初始匹配长度
  *matchlength = prelen;
  // 匹配失败
  return 0;
}

static int matchPlus(regex_t p, regex_t* pattern, const char* text, int* matchlength)
{
  const char* prepoint = text;
  while ((text[0] != '\0') && matchOne(p, *text))
  {
    text++;
    (*matchlength)++;
  }
  while (text > prepoint)
  {
    if (matchPattern(pattern, text--, matchlength))
      return 1;
    (*matchlength)--;
  }

  return 0;
}

static int matchQuestion(regex_t p, regex_t* pattern, const char* text, int* matchlength)
{
  // 如果模式类型为 UNUSED，直接返回匹配成功
  if (p.type == UNUSED)
    return 1;

  // 尝试匹配整个模式
  if (matchPattern(pattern, text, matchlength))
    return 1;

  // 如果文本不为空且与模式中的单个字符匹配，尝试匹配剩余部分的模式
  if (*text && matchOne(p, *text))
  {
    text++;

    // 如果成功匹配剩余的模式，增加匹配长度并返回匹配成功
    if (matchPattern(pattern, text, matchlength))
    {
      (*matchlength)++;
      return 1;
    }
  }

  // 匹配失败
  return 0;
}


static int matchPattern(regex_t* pattern, const char* text, int* matchlength)
{
  int pre = *matchlength;
  do
  {
    if ((pattern[0].type == UNUSED) || (pattern[1].type == QUESTIONMARK))
    {
      return matchQuestion(pattern[0], &pattern[2], text, matchlength);
    }
    else if (pattern[1].type == STAR)
    {
      return matchStar(pattern[0], &pattern[2], text, matchlength);
    }
    else if (pattern[1].type == PLUS)
    {
      return matchPlus(pattern[0], &pattern[2], text, matchlength);
    }
    else if ((pattern[0].type == END) && pattern[1].type == UNUSED)
    {
      return (text[0] == '\0');
    }
    else if (pattern[1].type == BRANCH)
    {
      int branchMatchLength = *matchlength; // 保存当前的matchlength
      if (matchPattern(pattern, text, matchlength)) // 匹配第一个分支
      {
        return 1;
      }
      *matchlength = branchMatchLength; // 恢复matchlength
      if (matchPattern(&pattern[2], text, matchlength)) // 匹配第二个分支
      {
        return 1;
      }
      return 0;
    }
  (*matchlength)++;
  }
  while ((text[0] != '\0') && matchOne(*pattern++, *text++));

  *matchlength = pre;
  return 0;
}

// 文本处理函数
void patternCheck(const char *file_path, GtkTextBuffer *outputBuffer) {
    char id[100][20];
    FILE *file;

    // 打开关键字文件
    file = fopen("/home/aymurat/ac-regex/regex_lib/regex-keyword.txt", "r");
    if (file == NULL) {
        // 在 GTK 界面上显示错误信息
        gtk_text_buffer_insert_at_cursor(outputBuffer, "无法打开关键字文件\n", -1);
        return;
    }

    // 读取关键字
    char keyword[20];
    int i = 0;
    while (fscanf(file, "%[^,],", keyword) != EOF) {
        strcpy(id[i++], keyword);
    }
    // 在 GTK 界面上显示关键字数量
    char keywordCountStr[50];
    sprintf(keywordCountStr, "共有%d个关键字\n", i);
    gtk_text_buffer_insert_at_cursor(outputBuffer, keywordCountStr, -1);
    fclose(file);

    // 打开待检测文件
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {
        // 在 GTK 界面上显示错误信息
        fprintf(stderr, "无法打开文件\n");
        gtk_text_buffer_insert_at_cursor(outputBuffer, "无法打开文件\n", -1);
        return;
    }

    // 获取文件大小
    fseek(fp, 0, SEEK_END);
    long fp_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    // 读取文件内容
    char *target = (char *)malloc(fp_size + 1);
    fread(target, 1, fp_size, fp);
    target[fp_size] = '\0';
    fclose(fp);

    // 执行文本处理操作
    int length;
    int j = 0;
    for (j = 0; j < i; j++) {
        int m = reMatcho(id[j], target, &length);
        if (m != -1) {
            // 在 GTK 界面上显示关键字匹配信息
            gtk_text_buffer_insert_at_cursor(outputBuffer, "\n", -1);
            rePrint(reCompile(id[j]));
            gtk_text_buffer_insert_at_cursor(outputBuffer, "\n", -1);
            gtk_text_buffer_insert_at_cursor(outputBuffer, "pattern '", -1);
            gtk_text_buffer_insert_at_cursor(outputBuffer, id[j], -1);
            gtk_text_buffer_insert_at_cursor(outputBuffer, "' matched, matched ", -1);
            char length_str[20];
            sprintf(length_str, "%i", length);
            gtk_text_buffer_insert_at_cursor(outputBuffer, length_str, -1);
            gtk_text_buffer_insert_at_cursor(outputBuffer, " chars.\n", -1);
        }
    }

    // 释放内存
    free(target);
}

// 回调函数，处理按钮点击事件
void regexButtonClicked(GtkWidget *widget, gpointer data) {
    GtkTextBuffer *buffer = (GtkTextBuffer *)data;

    // 获取用户输入的文件路径
    GtkTextIter start, end;
    gtk_text_buffer_get_start_iter(buffer, &start);
    gtk_text_buffer_get_end_iter(buffer, &end);
    const gchar *file_path = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);

    // 创建新的窗口用于显示输出
    GtkWidget *output_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(output_window), "匹配结果");
    gtk_window_set_default_size(GTK_WINDOW(output_window), 400, 200);

    // 创建文本视图和文本缓冲区用于输出
    GtkWidget *output_text_view = gtk_text_view_new();
    GtkTextBuffer *output_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(output_text_view));

    // 创建滚动窗口
    GtkWidget *output_scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(output_scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(output_scroll_window), output_text_view);

    // 将垂直布局容器添加到输出窗口
    GtkWidget *output_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(output_vbox), output_scroll_window, TRUE, TRUE, 0);

    // 将垂直布局容器添加到输出窗口
    gtk_container_add(GTK_CONTAINER(output_window), output_vbox);

    // 显示输出窗口
    gtk_widget_show_all(output_window);

    // 在新窗口中执行文本处理函数
    patternCheck(file_path, output_buffer);
}

int work(int argc,char *argv[]){
// 初始化 GTK
    gtk_init(&argc,&argv);

    // 创建主窗口
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "正则表达式引擎匹配");
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 200);

    // 创建文本框
    GtkWidget *text_view = gtk_text_view_new();
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));

    // 创建滚动窗口
    GtkWidget *scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(scroll_window), text_view);

    // 创建按钮
    GtkWidget *button = gtk_button_new_with_label("进行匹配");

    // 将按钮点击事件连接到回调函数
    g_signal_connect(button, "clicked", G_CALLBACK(regexButtonClicked), buffer);

    // 创建垂直布局容器
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    // 将垂直布局容器添加到主窗口
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // 显示所有窗口
    gtk_widget_show_all(window);

    // 运行 GTK 主循环
    gtk_main();

    return 0;}






