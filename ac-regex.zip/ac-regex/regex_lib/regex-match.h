#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
enum { UNUSED, DOT, BEGIN, END, QUESTIONMARK, STAR, PLUS, CHAR, CHAR_CLASS, INV_CHAR_CLASS, DIGIT, NOT_DIGIT, ALPHA, NOT_ALPHA, WHITESPACE, NOT_WHITESPACE, BRANCH  };
//    '.'        Dot, 匹配任意字符
//    '^'        Start anchor, 匹配串的开始端
//    '$'        End anchor, 匹配串末尾
//    '*'        Asterisk, 匹配重复（>=0）
//    '+'        Plus, 匹配重复(>= 1)
//    '?'        Question, 匹配对应内容有或者无
//    '[abc]'    Character class, match if one of {'a', 'b', 'c'}
//    '[^abc]'   Inverted class, match if NOT one of {'a', 'b', 'c'} -- NOTE: feature is currently broken!
//    '[a-zA-Z]' Character ranges, the character set of the ranges { a-z | A-Z }
//    '\s'       Whitespace, \t \f \r \n \v 和空格
//    '\S'       Non-whitespace
//    '\w'       Alphanumeric, [a-zA-Z0-9_]
//    '\W'       Non-alphanumeric
//    '\d'       Digits, [0-9]
//    '\D'       Non-digits
typedef struct regex_t
{
  unsigned char  type;   //定义在enum中
  union
  {
    unsigned char  ch;   /*      the character itself             */
    unsigned char* ccl;  /*  OR  a pointer to characters in class */
  } u;
} regex_t;
typedef struct regex_t* re_t;


/* 输入正则表达式pattern,得到对应的regex类型的串 */
re_t reCompile(const char* pattern);


/* 在text中查找pattern对应的串 */
int reMatchi(re_t pattern, const char* text, int* matchlength);


/* 在text中找到对应pattern的第一个串 */
int reMatcho(const char* pattern, const char* text, int* matchlength);

void patternCheck(const char *file_path, GtkTextBuffer *outputBuffer);

void regexButtonClicked(GtkWidget *widget, gpointer data);

int work(int argc, char *argv[]);

#define MAX_REGEXP_OBJECTS      30    /* Max number of regex symbols in expression. */
#define MAX_CHAR_CLASS_LEN      40    /* Max length of character-class buffer in.   */


