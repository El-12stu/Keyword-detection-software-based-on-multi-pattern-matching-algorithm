#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "regex-change.h"
void printWords(const char* words) {
    char* words_copy = strdup(words);
    char* token = strtok(words_copy, ",");
    int count = 1;
    while (token != NULL) {
        GtkTextIter iter;
        gtk_text_buffer_get_end_iter(regex_text_buffer, &iter);
        gchar* line = g_strdup_printf("%d. %s\n", count, token);
        gtk_text_buffer_insert(regex_text_buffer, &iter, line, -1);
        g_free(line);
        token = strtok(NULL, ",");
        count++;
    }
    free(words_copy);
}

int wordExists(const char* words, const char* word_to_find) {
    char* words_copy = strdup(words);
    char* token = strtok(words_copy, ",");
    while (token != NULL) {
        if (strcmp(token, word_to_find) == 0) {
            free(words_copy);
            return 1;
        }
        token = strtok(NULL, ",");
    }
    free(words_copy);
    return 0;
}

void deleteWord(const char* word_to_delete) {
    FILE* file;
    file = fopen(regex_file_path, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    char* words_copy = strdup(words);
    char* result = (char*)malloc(strlen(words_copy) * sizeof(char));
    result[0] = '\0';
    char* token = strtok(words_copy, ",");
    int found = 0;
    while (token != NULL) {
        if (strcmp(token, word_to_delete) == 0) {
            found = 1;
        } else {
            if (strlen(result) == 0) {
                strcpy(result, token);
            } else {
                strcat(result, ",");
                strcat(result, token);
            }
        }
        token = strtok(NULL, ",");
    }
    free(words_copy);
    
    if (found) {
        file = fopen(regex_file_path, "w");
        if (file == NULL) {
            GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                       GTK_DIALOG_DESTROY_WITH_PARENT,
                                                       GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK,
                                                       "无法打开文件");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
        fprintf(file, "%s", result);
        fclose(file);
        
        gtk_text_buffer_set_text(regex_text_buffer, "", -1);
        printWords(result);
    } else {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法删除单词'%s'，因为它不在列表中",
                                                   word_to_delete);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
    
    free(result);
    free(words);
}

void addWord(const char* word_to_add) {
    FILE* file;
    file = fopen(regex_file_path, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    if (wordExists(words, word_to_add)) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK,
                                                   "单词'%s'已存在于列表中",
                                                   word_to_add);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    } else {
        if (strlen(words) > 0) {
            strcat(words, ",");
        }
        strcat(words, word_to_add);
        
        file = fopen(regex_file_path, "w");
        if (file == NULL) {
            GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                       GTK_DIALOG_DESTROY_WITH_PARENT,
                                                       GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK,
                                                       "无法打开文件");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
        fprintf(file, "%s", words);
        fclose(file);
        
        gtk_text_buffer_set_text(regex_text_buffer, "", -1);
        printWords(words);
    }
    
    free(words);
}

void onAddButtonClicked(GtkWidget* button, gpointer user_data) {
    const gchar* word = gtk_entry_get_text(GTK_ENTRY(regex_entry));
    addWord(word);
    gtk_entry_set_text(GTK_ENTRY(regex_entry), "");
}

void onDeleteButtonClicked(GtkWidget* button, gpointer user_data) {
    const gchar* word = gtk_entry_get_text(GTK_ENTRY(regex_entry));
    deleteWord(word);
    gtk_entry_set_text(GTK_ENTRY(regex_entry), "");
}

void onQuitButtonClicked(GtkWidget* button, gpointer user_data) {
    gtk_main_quit();
}

void createUi() {
    GtkWidget* window;
    GtkWidget* add_button;
    GtkWidget* delete_button;
    GtkWidget* quit_button;
    GtkWidget* vbox;
    GtkWidget* scroll_window;
    
    gtk_init(NULL,NULL);
    
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450); // 设置窗口大小为450x450
    
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);
    
    scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);
    
     gtk_window_set_title(GTK_WINDOW(window), "关键词的增加删除");
    regex_text_view = gtk_text_view_new();
    regex_text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(regex_text_view));
    gtk_container_add(GTK_CONTAINER(scroll_window), regex_text_view);
    
    regex_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), regex_entry, FALSE, FALSE, 0);
    
    add_button = gtk_button_new_with_label("添加单词");
    g_signal_connect(add_button, "clicked", G_CALLBACK(onAddButtonClicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), add_button, FALSE, FALSE, 0);
    
    delete_button = gtk_button_new_with_label("删除单词");
    g_signal_connect(delete_button, "clicked", G_CALLBACK(onDeleteButtonClicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), delete_button, FALSE, FALSE, 0);
    
    quit_button = gtk_button_new_with_label("点击退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(onQuitButtonClicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), quit_button, FALSE, FALSE, 0);
    
    gtk_widget_show_all(window);
}

void readFile() {
    FILE* file;
    file = fopen(regex_file_path, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    printWords(words);
    
    free(words);
}

void regexChange() {
    createUi();
    readFile();
    gtk_main();
}


