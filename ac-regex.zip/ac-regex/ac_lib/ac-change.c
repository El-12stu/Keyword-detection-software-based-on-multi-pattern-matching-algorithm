#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "ac-change.h"

GtkWidget* text_view1;
GtkTextBuffer* text_buffer1;
GtkWidget* entry1;


void print_words(const char* words) {
    char* words_copy = strdup(words);
    char* token = strtok(words_copy, ",");
    int count = 1;
    while (token != NULL) {
        GtkTextIter iter;
        gtk_text_buffer_get_end_iter(text_buffer1, &iter);
        gchar* line = g_strdup_printf("%d. %s\n", count, token);
        gtk_text_buffer_insert(text_buffer1, &iter, line, -1);
        g_free(line);
        token = strtok(NULL, ",");
        count++;
    }
    free(words_copy);
}

int word_exists(const char* words, const char* word_to_find) {
    char* words_copy = strdup(words);
    char* token = strtok(words_copy, ",");
    while (token != NULL) {
        if (strcmp(token, word_to_find) == 0) {
            free(words_copy);
            return 1;
        }
        token = strtok(NULL, ",");
    }
    free(words_copy);
    return 0;
}

void delete_word(const char* word_to_delete) {
    FILE* file;
    file = fopen(file_path1, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    char* words_copy = strdup(words);
    char* result = (char*)malloc(strlen(words_copy) * sizeof(char));
    result[0] = '\0';
    char* token = strtok(words_copy, ",");
    int found = 0;
    while (token != NULL) {
        if (strcmp(token, word_to_delete) == 0) {
            found = 1;
        } else {
            if (strlen(result) == 0) {
                strcpy(result, token);
            } else {
                strcat(result, ",");
                strcat(result, token);
            }
        }
        token = strtok(NULL, ",");
    }
    free(words_copy);
    
    if (found) {
        file = fopen(file_path1, "w");
        if (file == NULL) {
            GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                       GTK_DIALOG_DESTROY_WITH_PARENT,
                                                       GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK,
                                                       "无法打开文件");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
        fprintf(file, "%s", result);
        fclose(file);
        
        gtk_text_buffer_set_text(text_buffer1, "", -1);
        print_words(result);
    } else {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法删除单词'%s'，因为它不在列表中",
                                                   word_to_delete);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
    
    free(result);
    free(words);
}

void add_word(const char* word_to_add) {
    FILE* file;
    file = fopen(file_path1, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    if (word_exists(words, word_to_add)) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_OK,
                                                   "单词'%s'已存在于列表中",
                                                   word_to_add);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    } else {
        if (strlen(words) > 0) {
            strcat(words, ",");
        }
        strcat(words, word_to_add);
        
        file = fopen(file_path1, "w");
        if (file == NULL) {
            GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                       GTK_DIALOG_DESTROY_WITH_PARENT,
                                                       GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK,
                                                       "无法打开文件");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            return;
        }
        fprintf(file, "%s", words);
        fclose(file);
        
        gtk_text_buffer_set_text(text_buffer1, "", -1);
        print_words(words);
    }
    
    free(words);
}

void on_add_button_clicked(GtkWidget* button, gpointer user_data) {
    const gchar* word = gtk_entry_get_text(GTK_ENTRY(entry1));
    add_word(word);
    gtk_entry_set_text(GTK_ENTRY(entry1), "");
}

void on_delete_button_clicked(GtkWidget* button, gpointer user_data) {
    const gchar* word = gtk_entry_get_text(GTK_ENTRY(entry1));
    delete_word(word);
    gtk_entry_set_text(GTK_ENTRY(entry1), "");
}

void on_quit_button_clicked1(GtkWidget* button, gpointer user_data) {
    gtk_main_quit();
}

void create_ui1() {
    GtkWidget* window;
    GtkWidget* add_button;
    GtkWidget* delete_button;
    GtkWidget* quit_button;
    GtkWidget* vbox;
    GtkWidget* scroll_window;
    
    gtk_init(NULL,NULL);
    
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450); // 设置窗口大小为450x450
    
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);
    
    scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);
    
     gtk_window_set_title(GTK_WINDOW(window), "关键词的增加删除");
    text_view1 = gtk_text_view_new();
    text_buffer1 = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view1));
    gtk_container_add(GTK_CONTAINER(scroll_window), text_view1);
    
    entry1 = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry1, FALSE, FALSE, 0);
    
    add_button = gtk_button_new_with_label("添加单词");
    g_signal_connect(add_button, "clicked", G_CALLBACK(on_add_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), add_button, FALSE, FALSE, 0);
    
    delete_button = gtk_button_new_with_label("删除单词");
    g_signal_connect(delete_button, "clicked", G_CALLBACK(on_delete_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), delete_button, FALSE, FALSE, 0);
    
    quit_button = gtk_button_new_with_label("点击退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(on_quit_button_clicked1), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), quit_button, FALSE, FALSE, 0);
    
    gtk_widget_show_all(window);
}

void read_file() {
    FILE* file;
    file = fopen(file_path1, "r+");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char* words = (char*)malloc((file_size + 1) * sizeof(char));
    fread(words, sizeof(char), file_size, file);
    words[file_size] = '\0';
    
    fclose(file);
    
    print_words(words);
    
    free(words);
}

void start_program() {
    create_ui1();
    read_file();
    gtk_main();
}

int main() {
    start_program();
    return 0;
}
