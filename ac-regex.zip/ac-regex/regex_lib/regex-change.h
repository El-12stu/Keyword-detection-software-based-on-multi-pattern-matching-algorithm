#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
GtkWidget* regex_text_view;
GtkTextBuffer* regex_text_buffer;
GtkWidget* regex_entry;
const char* regex_file_path = "/home/aymurat/ac-regex/regex_lib/regex-keyword.txt";

void printWords(const char* words);
int wordExists(const char* words, const char* word_to_find);
void deleteWord(const char* word_to_delete);
void addWord(const char* word_to_add);
void onAddButtonClicked(GtkWidget* button, gpointer user_data);
void onDeleteButtonClicked(GtkWidget* button, gpointer user_data);
void onQuitButtonClicked(GtkWidget* button, gpointer user_data);
void createUi();
void readFile();
void regexChange();

