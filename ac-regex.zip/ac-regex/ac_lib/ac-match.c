#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include<dirent.h>
#include <gtk/gtk.h>
const char* file_path = "/home/aymurat/ac-regex/ac_lib/ac-keyword.txt"; // 全局变量，文件路径
GtkWidget* text_view;
GtkTextBuffer* text_buffer;
GtkWidget* entry;


#define MAX_AHO_CHILD_NODE 256 /* Character 1 byte => 256 */

struct aho_trie_node
{
    unsigned char text;
    unsigned int ref_count;

    struct aho_trie_node* parent;
    struct aho_trie_node* child_list[MAX_AHO_CHILD_NODE];
    unsigned int child_count;

    bool text_end;
    struct aho_text_t* output_text; /* when text_end is true */

    struct aho_trie_node* failure_link;
    struct aho_trie_node* output_link;
};

struct aho_trie
{
    struct aho_trie_node root;
};

struct aho_match_t
{
    int id;
    unsigned long long pos;
    int len;
};

struct ahocorasick
{
#define AHO_MAX_TEXT_ID INT_MAX
    int accumulate_text_id;
    struct aho_text_t* text_list_head;
    struct aho_text_t* text_list_tail;
    int text_list_len;

    struct aho_trie trie;

    void (*callback_match)(void* arg, struct aho_match_t*);
    void* callback_arg;
};

struct aho_queue_node
{
    struct aho_queue_node* next, * prev;
    struct aho_trie_node* data;
};

struct aho_queue
{
    struct aho_queue_node* front;
    struct aho_queue_node* rear;
    unsigned int count;
};

struct aho_text_t
{
    int id;
    char* text;
    int len;
    struct aho_text_t* prev, * next;
};

typedef struct FileData {
    char file_name[100];
    char file_content[100000];
}FileData;

void aho_init(struct ahocorasick* aho);
void aho_destroy(struct ahocorasick* aho);
int aho_add_match_text(struct ahocorasick* aho, const char* text, unsigned int len);
bool aho_del_match_text(struct ahocorasick* aho, const int id);
void aho_clear_match_text(struct ahocorasick* aho);
void aho_create_trie(struct ahocorasick* aho);
void aho_clear_trie(struct ahocorasick* aho);
unsigned int aho_findtext(struct ahocorasick* aho, const char* data, unsigned long long data_len);
void aho_register_match_callback(struct ahocorasick* aho,void (*callback_match)(void* arg, struct aho_match_t*),void* arg);

void aho_queue_init(struct aho_queue* que)
{
    memset(que, 0x00, sizeof(struct aho_queue));
}
//y
bool aho_queue_empty(struct aho_queue* que)
{
    return (que->count == 0);
}
//y
struct aho_queue_node* aho_queue_dequeue(struct aho_queue* que)
{
    struct aho_queue_node* deque_node;
    struct aho_queue_node* after_last_node;
    if (aho_queue_empty(que) == true)
    {
        return NULL;
    }

    if (que->count == 1)
    {
        deque_node = que->rear;
        que->front = que->rear = NULL;
        que->count--;
        return deque_node;
    }

    deque_node = que->rear;

    after_last_node = que->rear->prev;
    after_last_node->next = NULL;
    que->rear = after_last_node;
    que->count--;
    return deque_node;
}
//y
void aho_queue_destroy(struct aho_queue* que)
{
    struct aho_queue_node* que_node = NULL;
    while ((que_node = aho_queue_dequeue(que)) != NULL)
    {
        free(que_node);
    }
}
//y
bool aho_queue_enqueue(struct aho_queue* que, struct aho_trie_node* node)
{
    struct aho_queue_node* que_node;
    que_node = (struct aho_queue_node*)malloc(sizeof(struct aho_queue_node));

    if (!que_node)
    {
        /* 无释放内存 */
        return false;
    }

    memset(que_node, 0x00, sizeof(struct aho_queue_node));
    que_node->data = node;

    if (que->count == 0)
    {
        que->rear = que_node;
        que->front = que_node;
        que->count++;
        return true;
    }

    que_node->prev = que->rear;
    que->rear->next = que_node;
    que->rear = que_node;
    que->count++;

    return true;
}
//y
void aho_init_trie(struct aho_trie* t) {
    memset(t, 0x00, sizeof(struct aho_trie));// 初始化使t中元素置为 0x00,即内存清零 
    memset(&(t->root), 0x00, sizeof(struct aho_trie_node));//将aho_trie中的构成root进行置空 
    t->root.text_end = false;//将每个数据节点的标识置为——不是关键词（是否关键词初始化） 
    t->root.ref_count = 1;//每个“关键词”的长度（即回溯个数）初始化为1 
}
//y
void aho_destroy_trie(struct aho_trie* t) {
    struct aho_queue queue;//定义一个aho_queue类型变量来存储待处理节点 
    aho_queue_init(&queue);//对上述变量初始化处理 
    aho_queue_enqueue(&queue, &(t->root));//通过函数调用将根节点中数据加入该变量 
    while (true) {//通过广度优先遍历方式对所有数据进行扫描，直到均置空，达成销毁数目的 
        struct aho_queue_node* queue_node = NULL;
        struct aho_trie_node* remove_node = NULL;
        int i = 0;
        queue_node = aho_queue_dequeue(&queue);//通过函数调用实现对该销毁数据结构的最后一个数据调出并更新该结构剩余的数据数及指针所指向点 
        if (queue_node == NULL) {//如果已经全部清除完则退出 
            break;
        }
        remove_node = queue_node->data;//使remove指向该节点对应数据 
        free(queue_node);//释放节点内存 
        for (i = 0; i < remove_node->child_count; i++) {//循环清理 
            aho_queue_enqueue(&queue, remove_node->child_list[i]);//将所有的子节点写入queue中在后续循环中清理释放 
        }
        if (remove_node->parent == NULL) {//若为根节点则继续 
            continue;
        }
        free(remove_node);//释放变量remove结构的内存 
    }//循环完成后实现全部数据清理，即销毁成功 
}
//y1
bool aho_add_trie_node(struct aho_trie* t, struct aho_text_t* text) {
    struct aho_trie_node* move = &(t->root);//移动寻找的变量 
    for (int i = 0; i < text->len; i++) {//for循环来遍历每个字符 
        unsigned char txt = text->text[i];
        bool find = false;//标记是否找到对应子节点 
        int j = 0;// 子节点在父节点中的索引 
        if (move->child_count == 0) {//若为0则无子节点，创建一个子节点 
            move->child_list[0] = (struct aho_trie_node*)malloc(sizeof(struct aho_trie_node));//申请空间 
            move->child_count++;
            memset(move->child_list[0], 0x00, sizeof(struct aho_trie_node));//进行置空 
            move->child_list[0]->text_end = false;//将每个数据节点的标识置为——不是关键词（是否关键词初始化） 
            move->child_list[0]->ref_count = 1;//每个“关键词”的长度（即回溯个数）初始化为1 
            move->child_list[0]->text = txt;//将子节点text变量设为当前字符 
            move->child_list[0]->parent = move;//将parent节点设为当前节点 
            move = move->child_list[0];//节点指向下一个，继续循环 
            continue;
        }
        if (move->child_count == MAX_AHO_CHILD_NODE) {//若已达最大限制则报错显示无法添加新节点 
            return false;
        }
        for (j = 0; j < move->child_count; j++) {//遍历过程中若有相同子节点则设置为TRUE 
            if (move->child_list[j]->text == txt) {
                find = true;
                break;
            }
        }
        if (find == true) {//记录为相同子节点的索引数 ，并将移动寻找指针指向该节点便于后续操作 
            move->child_list[j]->ref_count++;
            move = move->child_list[j];
        }
        else {//若无，则创造子节点 
            struct aho_trie_node* c_n = NULL;//引入变量子码
            move->child_list[move->child_count] = (struct aho_trie_node*)malloc(sizeof(struct aho_trie_node));//申请内存 
            c_n = move->child_list[move->child_count];//子节点赋值给变量 
            move->child_count++;//子(文本)节点自增便于后续字符匹配添加操作 
            memset(c_n, 0x00, sizeof(struct aho_trie_node)); //初始化 
            c_n->text_end = false;//初始化 
            c_n->ref_count = 1;//初始化 
            c_n->text = txt;// 文本赋值 
            c_n->parent = move;//将此节点接在移动节点后 
            move = c_n;//移动节点再次到文本字符扫描的末端 
        }
    }
    if (move) {//若不为空则遍历完后应标记为结束节点 
        move->text_end = true;
        move->output_text = text;
    }
    return true;
}
//y
bool link1(struct aho_trie_node* p, struct aho_trie_node* q) {//创建连接并返回是否成功
    struct aho_trie_node* pf = NULL;
    int i = 0;
    if (p->failure_link == NULL || p->parent == NULL) {//根节点判断，
        q->failure_link = p;
        return true;
    }
    pf = p->failure_link;
    for (i = 0; i < pf->child_count; i++) {//遍历寻找可能的跳转指针
        if (pf->child_list[i]->text == q->text) {
            q->failure_link = pf->child_list[i];//满足要求则连接
            if (pf->child_list[i]->text_end)q->output_link = pf->child_list[i];// 判断是否为结尾，若是则连接输出链接 
            else q->output_link = pf->child_list[i]->output_link;//不为结尾则连接其输出为链接 
            return true;//连接成功
        }
    }
    return false;
}
//y
void aho_connect_link(struct aho_trie* t) {//进行链接函数
    struct aho_queue que;//创建队列 
    aho_queue_init(&que);//进行初始化
    aho_queue_enqueue(&que, &(t->root));//使其从根节点入队
    while (true) {//进行广度优先遍历 
        /* p :parent, q : child node */
        struct aho_queue_node* que_n = NULL;
        struct aho_trie_node* p = NULL; //p即parent
        struct aho_trie_node* q = NULL;//q表示子节点
        int i = 0;
        que_n = aho_queue_dequeue(&que);//从que中出列一个元素进行赋值 
        if (que_n == NULL)break;//为空则退出
        p = que_n->data;
        free(que_n);
        for (i = 0; i < p->child_count; i++) {//遍历并调用函数创建链接
            struct aho_trie_node* pf = p;
            aho_queue_enqueue(&que, p->child_list[i]);
            q = p->child_list[i];
            while (link1(pf, q) == false)pf = pf->failure_link;//连接失败，继续寻找可能链接
        }
    }
    aho_queue_destroy(&que);//链接结束，释放空间 
}
//y
bool find(struct aho_trie_node** start, const unsigned char text) {
    struct aho_trie_node* search = NULL;
    int i = 0;
    search = *start;
    if (search == NULL)//为空
        return false;
    for (i = 0; i < search->child_count; i++) {
        if (search->child_list[i]->text == text) {
            *start = search->child_list[i];//查找成功，跳转指向至其子节点 
            return true;
        }
    }
    return false;
}
//y
struct aho_text_t* aho_find_trie_node(struct aho_trie_node** start, const unsigned char text) {
    while (find(start, text) == false) {//找寻是否成功判断
        if (*start == NULL || (*start)->parent == NULL)return NULL;//均为空，无可查的
        *start = (*start)->failure_link;//仍有非空，跳转至下一查找节点
    }
    if ((*start)->text_end)return (*start)->output_text;//若为一个关键词结尾，则返回关键词输出文本 
    if ((*start)->output_link)return (*start)->output_link->output_text;//如为输出链接，则返回该链接文本
    return NULL;//未果，返回，进行后续操作
}
//y
void aho_init(struct ahocorasick* aho)
{
    memset(aho, 0x00, sizeof(struct ahocorasick));
}
//y
void aho_destroy(struct ahocorasick* aho)
{
    aho_clear_match_text(aho);
    aho_destroy_trie(&aho->trie);
}
//y
int aho_add_match_text(struct ahocorasick* aho, const char* text, unsigned int len)
{
    struct aho_text_t* a_text = NULL;
    if (aho->accumulate_text_id == AHO_MAX_TEXT_ID)
    {
        return -1;
    }

    a_text = (struct aho_text_t*)malloc(sizeof(struct aho_text_t));
    if (!a_text)
        goto lack_free_mem;

    a_text->text = (char*)malloc(sizeof(char) * len + 1);
    if (!a_text->text)
        goto lack_free_mem;

    a_text->id = aho->accumulate_text_id++;
    memcpy(a_text->text, text, len + 1);
    a_text->len = len;
    a_text->prev = NULL;
    a_text->next = NULL;

    if (aho->text_list_head == NULL)
    {
        aho->text_list_head = a_text;
        aho->text_list_tail = a_text;
        aho->text_list_len++;
        return a_text->id;
    }

    aho->text_list_tail->next = a_text;
    a_text->prev = aho->text_list_tail;
    aho->text_list_tail = a_text;
    aho->text_list_len++;
    return a_text->id;

lack_free_mem:
    return -1;
}
//y
bool aho_del_match_text(struct ahocorasick* aho, const int id)
{
    struct aho_text_t* iter = NULL;
    for (iter = aho->text_list_head; iter != NULL; iter = iter->next)
    {
        /*if (iter->id > id)
        {
            return false;
        }
        */

        if (iter->id == id)
        {
            if (iter == aho->text_list_head)
            {
                aho->text_list_head = iter->next;
                free(iter->text);
            }
            else if (iter == aho->text_list_tail)
            {
                aho->text_list_tail = iter->prev;
                free(iter->text);
            }
            else
            {
                iter->prev->next = iter->next;
                iter->next->prev = iter->prev;
                free(iter->text);
            }
            free(iter);
            aho->text_list_len--;
            return true;
        }
    }
    return false;
}
//y
void aho_clear_match_text(struct ahocorasick* aho)
{
    for (int i = 0; i < aho->accumulate_text_id; i++)
    {
        aho_del_match_text(aho, i);
    }

    // reset id
    aho->accumulate_text_id = 0;
}
//y
void aho_create_trie(struct ahocorasick* aho)
{
    struct aho_text_t* iter = NULL;
    aho_init_trie(&(aho->trie));

    for (iter = aho->text_list_head; iter != NULL; iter = iter->next)
    {
        aho_add_trie_node(&(aho->trie), iter);
    }

    aho_connect_link(&(aho->trie));
}
//y
unsigned int aho_findtext(struct ahocorasick* aho, const char* data, unsigned long long data_len)
{
    int i = 0;
    int match_count = 0;
    struct aho_trie_node* travasal_node = NULL;

    travasal_node = &(aho->trie.root);

    for (i = 0; i < data_len; i++)
    {
        struct aho_match_t match;
        struct aho_text_t* result;

        result = aho_find_trie_node(&travasal_node, data[i]);
        if (result == NULL)
        {
            continue;
        }

        match.id = result->id;
        match.len = result->len;

        match.pos = i - result->len + 1;
        if (result->len == 1)
        {
            match.pos = i;
        }

        match_count++;
        if (aho->callback_match)
        {
            aho->callback_match(aho->callback_arg, &match);
        }
    }

    return match_count;
}
void aho_register_match_callback(struct ahocorasick* aho, void (*callback_match)(void* arg, struct aho_match_t*),void* arg)
{
    aho->callback_arg = arg;
    aho->callback_match = callback_match;
}
//y
void callback_match_total(void* arg, struct aho_match_t* m) {
    long long int* match_total = (long long int*)arg;
    (*match_total)++;
}//arg 指针型变量



void callback_match_pos(void* arg, struct aho_match_t* m) {
    char* text = (char*)arg;

    GtkTextIter iter;
    gtk_text_buffer_get_end_iter(text_buffer, &iter);

    gchar* line = g_strdup_printf("找到的关键词:");
    gtk_text_buffer_insert(text_buffer, &iter, line, -1);
    g_free(line);

    gchar* keyword = g_strndup(&text[m->pos], m->len);
    gtk_text_buffer_insert(text_buffer, &iter, keyword, -1);
    g_free(keyword);

    gchar* info = g_strdup_printf(" (关键词编号: %d 关键词位置: %llu 关键词长度: %d)\n", m->id, m->pos, m->len);
    gtk_text_buffer_insert(text_buffer, &iter, info, -1);
    g_free(info);
}

void output_result(int choice, FileData* file_data, struct ahocorasick* aho) {
    switch (choice) {
    case 1:
        gtk_text_buffer_insert_at_cursor(text_buffer, "文件路径：", -1);
        gtk_text_buffer_insert_at_cursor(text_buffer, file_data->file_name, -1);

        long long int match_total = 0;
        aho_register_match_callback(aho, callback_match_total, (void*)&match_total);
        aho_findtext(aho, file_data->file_content, strlen(file_data->file_content));

        gchar* info = g_strdup_printf("检索结果：%lld\n", match_total);
        gtk_text_buffer_insert_at_cursor(text_buffer, info, -1);
        g_free(info);
        break;
    case 2:
        gtk_text_buffer_insert_at_cursor(text_buffer, "文件名称：", -1);
        gtk_text_buffer_insert_at_cursor(text_buffer, file_data->file_name, -1);

        gtk_text_buffer_insert_at_cursor(text_buffer, "原文本：\n", -1);
        gtk_text_buffer_insert_at_cursor(text_buffer, file_data->file_content, -1);
        break;
    case 3:
        gtk_text_buffer_insert_at_cursor(text_buffer, "文件名称：", -1);
        gtk_text_buffer_insert_at_cursor(text_buffer, file_data->file_name, -1);

        gtk_text_buffer_insert_at_cursor(text_buffer, "详细检索结果：\n", -1);
        aho_register_match_callback(aho, callback_match_pos, (void*)file_data->file_content);
        aho_findtext(aho, file_data->file_content, strlen(file_data->file_content));
        break;
    }
}

void search_folder(const char* folder_path, int choice) {
    DIR* dir;
    struct dirent* ent;
    struct ahocorasick aho;
    aho_init(&aho);

    FILE* file;
    file = fopen(file_path, "r");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    char keyword[1000];
    while (fscanf(file, "%[^,],", keyword) != EOF) {
        int id = aho_add_match_text(&aho, keyword, strlen(keyword));

        gchar* info = g_strdup_printf("id[%d] = %s\n", id, keyword);
        GtkTextIter iter;
        gtk_text_buffer_get_end_iter(text_buffer, &iter);
        gtk_text_buffer_insert(text_buffer, &iter, info, -1);
        g_free(info);
    }
    fclose(file);

    aho_create_trie(&aho);

    if ((dir = opendir(folder_path)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if (ent->d_type == DT_REG) {
                char file_path[512];
                snprintf(file_path, sizeof(file_path), "%s/%s", folder_path, ent->d_name);
                FILE* fp = fopen(file_path, "r");
                if (fp == NULL) {
                    GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                                               GTK_MESSAGE_ERROR,
                                                               GTK_BUTTONS_OK,
                                                               "无法打开文件");
                    gtk_dialog_run(GTK_DIALOG(dialog));
                    gtk_widget_destroy(dialog);
                    continue;
                }

                fseek(fp, 0, SEEK_END);
                long fp_size = ftell(fp);
                fseek(fp, 0, SEEK_SET);

                FileData file_data;
                strcpy(file_data.file_name, file_path);

                char* target = (char*)malloc(fp_size + 1);
                fread(target, 1, fp_size, fp);
                target[fp_size] = '\0';

                strcpy(file_data.file_content, target);

                fclose(fp);

                output_result(choice, &file_data, &aho);

                free(target);
            }
        }
        closedir(dir);
    }
    else {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件夹");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    aho_destroy(&aho);
}
void on_match_button_clicked(GtkWidget* button, gpointer user_data) {
    struct ahocorasick aho;
    const gchar* file_path1 = gtk_entry_get_text(GTK_ENTRY(entry));
    FILE* fp;
    fp = fopen(file_path1, "r");
    if (fp == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    fseek(fp, 0, SEEK_END);
    long fp_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    char* target = (char*)malloc(fp_size + 1);
    fread(target, 1, fp_size, fp);
    target[fp_size] = '\0';

    fclose(fp);

    aho_init(&aho);

    FILE* file;
    file = fopen(file_path, "r");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    char keyword[1000];
    while (fscanf(file, "%[^,],", keyword) != EOF) {
        int id = aho_add_match_text(&aho, keyword, strlen(keyword));

        gchar* info = g_strdup_printf("id[%d] = %s\n", id, keyword);
        GtkTextIter iter;
        gtk_text_buffer_get_end_iter(text_buffer, &iter);
        gtk_text_buffer_insert(text_buffer, &iter, info, -1);
        g_free(info);
    }
    fclose(file);

    aho_create_trie(&aho);
    aho_register_match_callback(&aho, callback_match_pos, (void*)target);

    GtkTextIter iter;
    gtk_text_buffer_get_end_iter(text_buffer, &iter);

    gchar* info = g_strdup_printf("找到的所有的关键词:共%u个\n", aho_findtext(&aho, target, strlen(target)));
        gtk_text_buffer_get_end_iter(text_buffer, &iter);
        gtk_text_buffer_insert(text_buffer, &iter, info, -1);
        g_free(info);


    aho_destroy(&aho);
    free(target);
}

void on_result1_button_clicked(GtkWidget* button, gpointer user_data) {
    const gchar* file_path = gtk_entry_get_text(GTK_ENTRY(entry));
    int choice = 1;
    search_folder(file_path, choice);
}

void on_result2_button_clicked(GtkWidget* button, gpointer user_data) {
    const gchar* file_path = gtk_entry_get_text(GTK_ENTRY(entry));
    int choice = 2;
    search_folder(file_path, choice);
}

void on_result3_button_clicked(GtkWidget* button, gpointer user_data) {
    const gchar* file_path = gtk_entry_get_text(GTK_ENTRY(entry));
    int choice = 3;
    search_folder(file_path, choice);
}

void on_quit_button_clicked(GtkWidget* button, gpointer user_data) {
    gtk_main_quit();
}

void on_clear_button_clicked(GtkWidget* button, gpointer user_data) {
    gtk_text_buffer_set_text(text_buffer, "", -1); // 清空文本视图的内容
}

void work_code1() {
    GtkWidget* window;
    GtkWidget* result1_button;
    GtkWidget* result2_button;
    GtkWidget* result3_button;
    GtkWidget* quit_button;
    GtkWidget* clear_button;
    GtkWidget* vbox;
    GtkWidget* hbox1;
    GtkWidget* hbox2;
    GtkWidget* hbox3;
    GtkWidget* scroll_window;

    gtk_init(NULL, NULL);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_window_set_title(GTK_WINDOW(window), "文件夹 地址方式关键词匹配");
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);

    text_view = gtk_text_view_new();
    text_buffer = gtk_text_buffer_new(NULL);
    gtk_text_view_set_buffer(GTK_TEXT_VIEW(text_view), text_buffer);
    gtk_container_add(GTK_CONTAINER(scroll_window), text_view);

    entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry, FALSE, FALSE, 0);

    hbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(vbox), hbox1, FALSE, FALSE, 0);

    result1_button = gtk_button_new_with_label("仅输出文件路径和检索结果");
    g_signal_connect(result1_button, "clicked", G_CALLBACK(on_result1_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox1), result1_button, TRUE, TRUE, 0);

    result2_button = gtk_button_new_with_label(" 输出被检测的文件名称和原文本");
    g_signal_connect(result2_button, "clicked", G_CALLBACK(on_result2_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox1), result2_button, TRUE, TRUE, 0);

    result3_button = gtk_button_new_with_label("输出文件名称和详细检索结果");
    g_signal_connect(result3_button, "clicked", G_CALLBACK(on_result3_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox1), result3_button, TRUE, TRUE, 0);

    hbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(vbox), hbox2, FALSE, FALSE, 0);

    quit_button = gtk_button_new_with_label("点击退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(on_quit_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox2), quit_button, TRUE, TRUE, 0);

    clear_button = gtk_button_new_with_label("清空");
    g_signal_connect(clear_button, "clicked", G_CALLBACK(on_clear_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox2), clear_button, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
        gtk_main();
}

void work_code2() {
    GtkWidget* window;
    GtkWidget* match_button;
    GtkWidget* quit_button;
    GtkWidget* vbox;
    GtkWidget* scroll_window;

    gtk_init(NULL, NULL);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_window_set_title(GTK_WINDOW(window), "文件地址方式关键词匹配");
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);

    text_view = gtk_text_view_new();
    text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    gtk_container_add(GTK_CONTAINER(scroll_window), text_view);

    entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry, FALSE, FALSE, 0);

    match_button = gtk_button_new_with_label("匹配关键词");
    g_signal_connect(match_button, "clicked", G_CALLBACK(on_match_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), match_button, FALSE, FALSE, 0);

    quit_button = gtk_button_new_with_label("点击退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(on_quit_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), quit_button, FALSE, FALSE, 0);

    gtk_widget_show_all(window);
    gtk_main();
}
 void on_match_button_clicked3(GtkWidget* button, gpointer user_data) {
    struct ahocorasick aho;
    const gchar* target = gtk_entry_get_text(GTK_ENTRY(entry));

    aho_init(&aho);
    FILE* file;
    file = fopen(file_path, "r");
    if (file == NULL) {
        GtkWidget* dialog = gtk_message_dialog_new(NULL,
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "无法打开文件");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    char keyword[1000];
    while (fscanf(file, "%[^,],", keyword) != EOF) {
        int id = aho_add_match_text(&aho, keyword, strlen(keyword));
        gchar* info = g_strdup_printf("id[%d] = %s\n", id, keyword);
        GtkTextIter iter;
        gtk_text_buffer_get_end_iter(text_buffer, &iter);
        gtk_text_buffer_insert(text_buffer, &iter, info, -1);
        g_free(info);
    }
    fclose(file);
    aho_create_trie(&aho);
    aho_register_match_callback(&aho, callback_match_pos, (void*)target);

    GtkTextIter iter;
    gtk_text_buffer_get_end_iter(text_buffer, &iter);

    gchar* info = g_strdup_printf("找到的所有的关键词:共%u个\n输入进行匹配的文本:\n", aho_findtext(&aho, target, strlen(target)));
    gchar* result = g_strdup_printf("%s%s", info, target);
    gtk_text_buffer_get_end_iter(text_buffer, &iter);
    gtk_text_buffer_insert(text_buffer, &iter, result, -1);
    g_free(result);

    aho_destroy(&aho);
}

void work_code3() {
    GtkWidget* window;
    GtkWidget* match_button;
    GtkWidget* quit_button;
    GtkWidget* vbox;
    GtkWidget* scroll_window;

    gtk_init(NULL,NULL);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    scroll_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_window_set_title(GTK_WINDOW(window), "按直接输入文本检索");
    gtk_box_pack_start(GTK_BOX(vbox), scroll_window, TRUE, TRUE, 0);

    text_view = gtk_text_view_new();
    text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    gtk_container_add(GTK_CONTAINER(scroll_window), text_view);

    entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry, FALSE, FALSE, 0);

    match_button = gtk_button_new_with_label("匹配关键词");
    g_signal_connect(match_button, "clicked", G_CALLBACK(on_match_button_clicked3), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), match_button, FALSE, FALSE, 0);

    quit_button = gtk_button_new_with_label("点击退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(on_quit_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), quit_button, FALSE, FALSE, 0);

    gtk_widget_show_all(window);
    gtk_main();
}
void on_work_code1_button_clicked(GtkWidget* button, gpointer user_data) {
    work_code1();
}

void on_work_code2_button_clicked(GtkWidget* button, gpointer user_data) {
    work_code2();
}

void on_work_code3_button_clicked(GtkWidget* button, gpointer user_data) {
    work_code3();
}

void create_ui() {
    GtkWidget* window;
    GtkWidget* work_code1_button;
    GtkWidget* work_code2_button;
    GtkWidget* work_code3_button;
    GtkWidget* quit_button;
    GtkWidget* vbox;
    GtkWidget* hbox1;
    GtkWidget* hbox2;
    GtkWidget* hbox3;



    gtk_init(NULL,NULL);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_set_size_request(window, 450, 450);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    hbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(vbox), hbox1, FALSE, FALSE, 0);

    gtk_window_set_title(GTK_WINDOW(window), "关键词检测"); // 设置窗口标题为"我的窗口"

    work_code1_button = gtk_button_new_with_label("按整个文件夹扫描方式检索");
    g_signal_connect(work_code1_button, "clicked", G_CALLBACK(on_work_code1_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox1), work_code1_button, TRUE, TRUE, 0);

    hbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(vbox), hbox2, FALSE, FALSE, 0);

    work_code2_button = gtk_button_new_with_label("按单个文件方式检索");
    g_signal_connect(work_code2_button, "clicked", G_CALLBACK(on_work_code2_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox2), work_code2_button, TRUE, TRUE, 0);

    hbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(vbox), hbox3, FALSE, FALSE, 0);

    work_code3_button = gtk_button_new_with_label("按直接输入文本检索");
    g_signal_connect(work_code3_button, "clicked", G_CALLBACK(on_work_code3_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox3), work_code3_button, TRUE, TRUE, 0);

    quit_button = gtk_button_new_with_label("退出程序");
    g_signal_connect(quit_button, "clicked", G_CALLBACK(on_quit_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), quit_button, FALSE, FALSE, 0);

    gtk_widget_show_all(window);

    gtk_main();
}

