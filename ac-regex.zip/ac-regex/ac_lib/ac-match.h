#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include<dirent.h>
#include <gtk/gtk.h>
const char* file_path = "/home/aymurat/ac-regex/ac_lib/ac-keyword.txt"; // 全局变量，文件路径
GtkWidget* text_view;
GtkTextBuffer* text_buffer;
GtkWidget* entry;


#define MAX_AHO_CHILD_NODE 256 /* Character 1 byte => 256 */

struct aho_trie_node
{
    unsigned char text;
    unsigned int ref_count;

    struct aho_trie_node* parent;
    struct aho_trie_node* child_list[MAX_AHO_CHILD_NODE];
    unsigned int child_count;

    bool text_end;
    struct aho_text_t* output_text; /* when text_end is true */

    struct aho_trie_node* failure_link;
    struct aho_trie_node* output_link;
};

struct aho_trie
{
    struct aho_trie_node root;
};

struct aho_match_t
{
    int id;
    unsigned long long pos;
    int len;
};

struct ahocorasick
{
#define AHO_MAX_TEXT_ID INT_MAX
    int accumulate_text_id;
    struct aho_text_t* text_list_head;
    struct aho_text_t* text_list_tail;
    int text_list_len;

    struct aho_trie trie;

    void (*callback_match)(void* arg, struct aho_match_t*);
    void* callback_arg;
};

struct aho_queue_node
{
    struct aho_queue_node* next, * prev;
    struct aho_trie_node* data;
};

struct aho_queue
{
    struct aho_queue_node* front;
    struct aho_queue_node* rear;
    unsigned int count;
};

struct aho_text_t
{
    int id;
    char* text;
    int len;
    struct aho_text_t* prev, * next;
};

typedef struct FileData {
    char file_name[100];
    char file_content[100000];
}FileData;

void aho_init(struct ahocorasick* aho);
void aho_destroy(struct ahocorasick* aho);
int aho_add_match_text(struct ahocorasick* aho, const char* text, unsigned int len);
bool aho_del_match_text(struct ahocorasick* aho, const int id);
void aho_clear_match_text(struct ahocorasick* aho);
void aho_create_trie(struct ahocorasick* aho);
void aho_clear_trie(struct ahocorasick* aho);
unsigned int aho_findtext(struct ahocorasick* aho, const char* data, unsigned long long data_len);
void aho_register_match_callback(struct ahocorasick* aho, void (*callback_match)(void* arg, struct aho_match_t*), void* arg);
void aho_queue_init(struct aho_queue* que); 
bool aho_queue_empty(struct aho_queue* que);
struct aho_queue_node* aho_queue_dequeue(struct aho_queue* que);
void aho_queue_destroy(struct aho_queue* que);
bool aho_queue_enqueue(struct aho_queue* que, struct aho_trie_node* node);
void aho_init_trie(struct aho_trie* t);
void aho_destroy_trie(struct aho_trie* t);
bool aho_add_trie_node(struct aho_trie* t, struct aho_text_t* text);
bool link1(struct aho_trie_node* p, struct aho_trie_node* q);
void aho_connect_link(struct aho_trie* t);
bool find(struct aho_trie_node** start, const unsigned char text) ;
struct aho_text_t* aho_find_trie_node(struct aho_trie_node** start, const unsigned char text);
void callback_match_total(void* arg, struct aho_match_t* m);
void callback_match_pos(void* arg, struct aho_match_t* m);
void output_result(int choice, FileData* file_data, struct ahocorasick* aho);
void search_folder(const char* folder_path, int choice);
void on_match_button_clicked(GtkWidget* button, gpointer user_data);
void on_result1_button_clicked(GtkWidget* button, gpointer user_data);
void on_result2_button_clicked(GtkWidget* button, gpointer user_data);
void on_result3_button_clicked(GtkWidget* button, gpointer user_data);
void on_quit_button_clicked(GtkWidget* button, gpointer user_data);
void on_clear_button_clicked(GtkWidget* button, gpointer user_data);
void on_match_button_clicked3(GtkWidget* button, gpointer user_data);
void work_code1();
void work_code2();
void work_code3();
void on_work_code1_button_clicked(GtkWidget* button, gpointer user_data);
void on_work_code2_button_clicked(GtkWidget* button, gpointer user_data);
void on_work_code3_button_clicked(GtkWidget* button, gpointer user_data);
void create_ui();
//相关编译指令：gcc try.c -o try `pkg-config --cflags --libs gtk+-3.0` 
