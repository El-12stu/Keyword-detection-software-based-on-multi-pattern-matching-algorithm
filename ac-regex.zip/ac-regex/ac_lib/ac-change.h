#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
GtkWidget* text_view1;
GtkTextBuffer* text_buffer1;
GtkWidget* entry1;
const char* file_path1 = "/home/aymurat/ac-regex/ac_lib/ac-keyword.txt"; // 全局变量，文件路径

void print_words(const char* words);
int word_exists(const char* words, const char* word_to_find);
void delete_word(const char* word_to_delete);
void add_word(const char* word_to_add);
void on_add_button_clicked(GtkWidget* button, gpointer user_data);
void on_delete_button_clicked(GtkWidget* button, gpointer user_data);
void on_quit_button_clicked1(GtkWidget* button, gpointer user_data);
void create_ui1();
void read_file();
void start_program();
//相关编译指令gcc gjc.c -o 关键词 `pkg-config --cflags --libs gtk+-3.0`
 
